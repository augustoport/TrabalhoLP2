Fábio de Carvalho Rabello - BP3012654
Augusto Soares da Silva Portella - BP3012441
Osvaldo Gonçalves De Oliveira Júnior - BP3009211

A questão do gerenciamento do condomínio resultará num aplicativo simples e de alta funcionalidade, e o principal objetivo seria o controle sobre diversas áreas da localidade como portaria, academia, salão de festas, quadras, área de lazer, salão de jogos e possíveis outras salas.
Para o controle serão armazenadas o nome do utilizador, bloco e número do apartamento, horário de entrada e saída, caso não for morador serão informados os dados do morador que permitiu a entrada.

Instruções de Uso:

Em uma nova maquina deverá ser executado o comando createTable(), para a criação das tabelas e o "start" do banco de dados
após isso vem a principal interface da aplicação, o menu, nele ocorre a seleção do que será mostrado ou alterado
é importante que para as opções de alteração seja consultado a função de exibição, para ter o conhecimento do conteudo e manipula-lo corretamente
seguidas estas instruções o aplicativo cumprirá sua função e o controle do ambiente estará na palma de suas mãos.
Bom uso :)

