Fábio de Carvalho Rabello - BP3012654
Augusto Soares da Silva Portella - BP3012441
Osvaldo Gonçalves De Oliveira Júnior - BP3009211

A questão do gerenciamento do condomínio resultará num aplicativo simples e de alta funcionalidade, e o principal objetivo seria o controle sobre diversas áreas da localidade como portaria, academia, salão de festas, quadras, área de lazer, salão de jogos e possíveis outras salas.
Para o controle serão armazenadas o nome do utilizador, bloco e número do apartamento, horário de entrada e saída, caso não for morador serão informados os dados do morador que permitiu a entrada.
