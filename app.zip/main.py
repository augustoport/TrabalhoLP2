import sqlite3  
connection = sqlite3.connect('condominio.db')
c = connection.cursor()
#Função opção 2
def adicionarDado(connection,vsql):
    c.execute(vsql)
    connection.commit()
    print("registro inserido")
#Função Criação de tabelas 
def createTable():
  c.execute('CREATE TABLE IF NOT EXISTS condomino(idmorador integer auto_increment primary key, n_apartamento integer not null, nome_morador varchar (20),bloco integer not null )')
  c.execute('CREATE TABLE IF NOT EXISTS areasLazer(idarea integer auto_increment primary key ,nome_area varchar (20),atividades varchar (10), responsavel varchar (20))')
#Função do Menu
def menu():
    title = 'Manutenção de dados da planilha'
    print('--' * len(title))
    print(title)
    print('--' * len(title))
    print('')
    print('Selecione a opção desejada. Digite 0 para sair. \n')
    print('1. Exibir todos os registros.')
    print('2. Adicionar registros aos condominos.')
    print('3. Adicionar registros às areas de lazer')
    print('4. Pesquisar registros.')
    print('5. Atualizar registros.')
    print('6. Excluir registros.')
    escolha = int(input('Entre com a opção desejada: '))
    print('\n')
    return escolha
#Função opção 1 e 3  
def exibir(connection,sql):
  c.execute(sql)
  result = c.fetchall()
  print(result)
#Função opção 4
def atualizar(connection,sql):
  c.execute(sql)
  connection.commit()
  print("Registro atualizado ")
#Função opção 5
def delete(connection,sql):
  c.execute(sql)
  connection.commit()
  print("Registro Removido")

createTable()
escolha = menu()
while escolha != 0:
   if escolha == 1:
        psql = "SELECT * FROM areasLazer,condomino"
        exibir(connection,psql)
        escolha = menu()
   if escolha == 2:
        idm,apartamento,nome,nbloco =input("Digite o id do morador "),input("Digite o numero do apartamento a ser registrado: "), input("Digite o nome a ser registrado: "),input("Digite o bloco referente ao cadastro: ")
        vsql = "INSERT INTO condomino (idmorador,n_apartamento,nome_morador,bloco) VALUES('"+idm+"','"+apartamento+"','"+nome+"','"+nbloco+"')"
        adicionarDado(connection,vsql)
        escolha = menu()
   if escolha == 3:
      id,nome,ativ,resp = input("Digite o id da area "),input("Digite o nome da area "),input("Digite as atividades da area "),input("Digite o nome do responsavel ")
      vsql = "INSERT INTO areasLazer(idarea,nome_area,atividades,responsavel) VALUES('"+id+"','"+nome+"','"+ativ+"','"+resp+"')"
      adicionarDado(connection,vsql)
      escolha = menu()
   if escolha == 4:
       n = input("Digite 1 se deseja ver os registros dos condominos: \n2 se deseja ver os registros da area de lazer: ")
       if n == '1':
         psql = "SELECT * FROM condomino"
         exibir(connection,psql)
       elif n == '2':
         psql = "SELECT * FROM areasLazer"
         exibir(connection,psql)
       else:
        print("Opção invalida, digite 1 ou 2 ")
        n = input("Digite 1 se deseja ver os registros dos condominos: \n2 se deseja ver os registros da area de lazer: ")
   if escolha == 5:
       n = input("Digite 1 se deseja atualizar os registros dos condominos: \n2 se deseja atualizar os registros da area de lazer: ")
       if n == '1':
         nome,nome_novo  = input("Digite o nome à ser atualizado: "), input("Digite o nome a ser registrado: ")
         vsql = "UPDATE condomino SET nome_morador = '"+nome_novo+"'WHERE nome_morador = '"+nome+"'"
         atualizar(connection,vsql)
       elif n == '2':
         resp,n_resp = input("Digite o nome do responsavel à ser atualizado: "), input("Digite o nome do responsavel à ser registrado: ")
         psql = "UPDATE areasLazer SET responsavel = '"+n_resp+"' WHERE responsavel = '"+resp+"'"
         atualizar(connection,psql)
       else:
        print("Opção invalida, digite 1 ou 2 ")
        n = input("Digite 1 se deseja ver os registros dos condominos: \n2 se deseja ver os registros da area de lazer: ")
   if escolha == 6:
       n = input("Digite 1 se deseja excluir os registros dos condominos: \n2 se deseja excluir os registros da area de lazer: ")
       if n == '1':
        n = input("Digite o numero correspondente ao id que deseja deletar: ")
        vsql = "DELETE FROM condomino WHERE idmorador = '"+n+"'"
        delete(connection,vsql)
       elif n == '2':
         n = input("Digite o numero correspondente ao id que deseja deletar: ")
         vsql = "DELETE FROM areasLazer WHERE idarea = '"+n+"'"
         delete(connection,vsql)
   elif escolha > 5 or escolha < 0:
      print("Opção errada,digite de 1 a 5 ")
      escolha = menu() 
else:
    print("volte sempre :)")