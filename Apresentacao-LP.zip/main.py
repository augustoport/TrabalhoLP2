import sqlite3  
connection = sqlite3.connect('condominio.db')
c = connection.cursor()
#Definir tabela area de lazer
def arealazer():
   sql = "INSERT INTO areaslazer(idarea,nome_area,atividades,responsavel)VALUES('1','Quadra','Jogar bola','Bruno'),('2','Academia','Possibilitar aos condominos o uso de equipamentos de academia','Leonardo Stronda'),('3','Piscina','Conceder aos condominos o uso de uma piscina', 'Luana'),('4','Lan House','Possibilitar aos condominos uma gameplay elevada','Yodão')"
   c.execute(sql)
#Função opção 2
def adicionarDado(connection,vsql):
    c.execute(vsql)
    connection.commit()
    print("registro inserido")
#Função Criação de tabelas 
def createTable():
  c.execute('CREATE TABLE IF NOT EXISTS condomino(idmorador integer auto_increment primary key, n_apartamento integer not null, nome_morador varchar (20),bloco integer not null )')
  c.execute('CREATE TABLE IF NOT EXISTS areasLazer(idarea integer auto_increment primary key ,nome_area varchar (20),atividades varchar (10), responsavel varchar (20))')
#Função do Menu
def menu():
    title = 'Manutenção de dados da planilha'
    print('--' * len(title))
    print(title)
    print('--' * len(title))
    print('')
    print('Selecione a opção desejada. Digite 0 para sair. \n')
    print('1. Exibir todos os registros.')
    print('2. Adicionar registros.')
    print('3. Pesquisar registros.')
    print('4. Atualizar registros.')
    print('5. Excluir registros.')
    escolha = int(input('Entre com a opção desejada: '))
    print('\n')
    return escolha
#Função opção 1 e 3  
def exibir(connection,sql):
  c.execute(sql)
  result = c.fetchall()
  for r in result:
          print(r)
  return(r)
#Função opção 4
def atualizar(connection,sql):
  c.execute(sql)
  connection.commit()
  print("Registro atualizado ")
#Função opção 5
def delete(connection,sql):
  c.execute(sql)
  connection.commit()
  print("Registro Removido")

createTable()
arealazer()
escolha = menu()
while escolha != 0:
    if escolha == 1:
        psql = "SELECT * FROM areasLazer,condomino"
        exibir(connection,psql)
        escolha = menu()
    if escolha == 2:
        apartamento,nome,nbloco =input("Digite o numero do apartamento a ser registrado: "), input("Digite o nome a ser registrado: "),input("Digite o bloco referente ao cadastro: ")
        vsql = "INSERT INTO condomino (n_apartamento,nome_morador,bloco) VALUES('"+apartamento+"','"+nome+"','"+nbloco+"')"
        adicionarDado(connection,vsql)
        escolha = menu()
    if escolha == 3:
       n = input("Digite 1 se deseja ver os registros dos condominos: \n2 se deseja ver os registros da area de lazer: ")
       if n == '1':
         psql = "SELECT * FROM condomino"
         exibir(connection,psql)
       elif n == '2':
         psql = "SELECT * FROM areasLazer"
         exibir(connection,psql)
       else:
        print("Opção invalida, digite 1 ou 2 ")
        n = input("Digite 1 se deseja ver os registros dos condominos: \n2 se deseja ver os registros da area de lazer: ")
    if escolha == 4:
       n = input("Digite 1 se deseja atualizar os registros dos condominos: \n2 se deseja atualizar os registros da area de lazer: ")
       if n == '1':
         nome,nome_novo  = input("Digite o nome à ser atualizado: "), input("Digite o nome a ser registrado: ")
         vsql = "UPDATE condomino SET nome_morador = '"+nome_novo+"'WHERE nome_morador = '"+nome+"'"
         atualizar(connection,vsql)
       elif n == '2':
         resp,n_resp = input("Digite o nome do responsavel à ser atualizado: "), input("Digite o nome do responsavel à ser registrado: ")
         psql = "UPDATE areasLazer SET responsavel = '"+n_resp+"' WHERE responsavel = '"+resp+"'"
         atualizar(connection,psql)
       else:
        print("Opção invalida, digite 1 ou 2 ")
        n = input("Digite 1 se deseja ver os registros dos condominos: \n2 se deseja ver os registros da area de lazer: ")
    if escolha == 5:
       n = input("Digite 1 se deseja excluir os registros dos condominos: \n2 se deseja excluir os registros da area de lazer: ")
       if n == '1':
        n = input("Digite o numero correspondente ao id que deseja deletar: ")
        vsql = "DELETE FROM condomino WHERE idmorador = '"+n+"'"
        delete(connection,vsql)
       elif n == '2':
         n = input("Digite o numero correspondente ao id que deseja deletar: ")
         vsql = "DELETE FROM areasLazer WHERE idarea = '"+n+"'"
         delete(connection,vsql)
    elif escolha > 5 or escolha < 0:
      print("Opção errada,digite de 1 a 5 ")
      escolha = menu() 
else:
    print("volte sempre :)")